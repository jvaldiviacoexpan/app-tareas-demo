package com.coopeuch.springboot.tareas.app.models.services;

import java.util.List;

import com.coopeuch.springboot.tareas.app.models.entity.Tarea;
import com.coopeuch.springboot.tareas.app.models.entity.TareaRest;


public interface ITareaService {

	public String addTarea(TareaRest tarea);
	public List<Tarea> findAll();
	public Tarea findById(Integer id);
	public String deleteById(Integer id);
	public String updateById(TareaRest tarea, Integer id);
	
	
}
