package com.coopeuch.springboot.tareas.app.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.coopeuch.springboot.tareas.app.models.entity.Tarea;
import com.coopeuch.springboot.tareas.app.models.entity.TareaRest;
import com.coopeuch.springboot.tareas.app.models.services.ITareaService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@RestController
@RequestMapping("/tareas")
@Api(value="API REST Tareas")
@CrossOrigin(origins="*")
public class TareaController {

	@Autowired
	private ITareaService tareaService;
	
	@RequestMapping(value = "/getall", method = RequestMethod.GET)
	@ApiOperation(value="Retorna lista de tareas.")
	public List<Tarea> listar() {
		return tareaService.findAll();
	}
	
	@RequestMapping(value = "get/{id}", method = RequestMethod.GET)
	@ApiOperation(value="Obtiene la tarea mediante ID")
	public Tarea obtenerDetalle(@PathVariable Integer id) {
		return tareaService.findById(id);
	}
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	@ApiOperation(value="Agrega una nueva tarea.")
	public String agregarTarea(@RequestBody TareaRest tarea) {
		return tareaService.addTarea(tarea);
	}
	
	@RequestMapping(value = "delete/{id}", method = RequestMethod.DELETE)
	@ApiOperation(value="Eliminar tarea mediante ID")
	public String eliminarTarea(@PathVariable Integer id) {
		return tareaService.deleteById(id);
	}
	
	@RequestMapping(value = "update/{id}", method = RequestMethod.PUT)
	@ApiOperation(value="Modificar tarea mediante ID.")
	public String modificarTarea(@RequestBody TareaRest tarea, @PathVariable Integer id) {
		return tareaService.updateById(tarea, id);
	}
	
}
