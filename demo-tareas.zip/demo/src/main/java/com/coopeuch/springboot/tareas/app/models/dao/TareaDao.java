package com.coopeuch.springboot.tareas.app.models.dao;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.coopeuch.springboot.tareas.app.models.entity.Tarea;


public interface TareaDao extends CrudRepository<Tarea, Integer>{

	// No utilizado
	@Modifying
	@Query(value = "update tareas u set u.descripcion = :descripcion where u.id = :id", nativeQuery = true)
    void updateTareaById(@Param("descripcion") String descripcion, @Param("id") Integer id);
}
