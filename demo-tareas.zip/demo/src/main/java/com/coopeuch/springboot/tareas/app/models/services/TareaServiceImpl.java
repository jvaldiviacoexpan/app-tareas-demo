package com.coopeuch.springboot.tareas.app.models.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coopeuch.springboot.tareas.app.models.dao.TareaDao;
import com.coopeuch.springboot.tareas.app.models.entity.Tarea;
import com.coopeuch.springboot.tareas.app.models.entity.TareaRest;


@Service
public class TareaServiceImpl implements ITareaService {

	@Autowired
	private TareaDao tareaDao;
	
	@Override
	public String addTarea(TareaRest tarea) {
		if(tarea.getDescripcion() == null) {
			return "La descripción no puede estar vacía.";
		} else {
			Tarea tareaE = new Tarea();
			tareaE.setDescripcion(tarea.getDescripcion());
			tareaE.setFechaCreacion(tarea.getFechaCreacion());
			tareaE.setVigente(tarea.isVigente());
			tareaDao.save(tareaE);
			return "Tarea grabada.";
		}
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<Tarea> findAll() {
		return (List<Tarea>) tareaDao.findAll();
	}

	@Override
	public Tarea findById(Integer id) {
		return tareaDao.findById(id).orElse(null);
	}

	@Override
	public String deleteById(Integer id) {
		if(this.findById(id) == null) {
			return "Tarea no encontrada.";
		} else {
			tareaDao.deleteById(id);
			return "Tarea Eliminada.";
		}
	}

	@Override
	public String updateById(TareaRest tarea, Integer id) {
		Tarea getTarea = this.findById(id);
		if(getTarea == null) {
			return "Tarea no encontrada.";
		} else {
			if(tarea.getDescripcion().length() == 0) {
				return "La descripción esta vacía.";
			}
			
			getTarea.setDescripcion(tarea.getDescripcion());
			getTarea.setFechaCreacion(tarea.getFechaCreacion());
			getTarea.setVigente(tarea.isVigente());
			tareaDao.save(getTarea);
			return "Tarea modificada.";
		}
	}

	
	
	
	
	

}
