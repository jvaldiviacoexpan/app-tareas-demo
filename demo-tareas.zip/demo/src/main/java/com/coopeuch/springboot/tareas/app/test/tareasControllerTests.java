package com.coopeuch.springboot.tareas.app.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import com.coopeuch.springboot.tareas.app.controllers.TareaController;
import com.coopeuch.springboot.tareas.app.models.entity.Tarea;
import com.coopeuch.springboot.tareas.app.models.services.ITareaService;

@ExtendWith(SpringExtension.class)
@WebMvcTest(TareaController.class)
public class tareasControllerTests {

	@MockBean
	ITareaService tareaService;
	
	@Autowired
    MockMvc mockMvc;
	
	@Test
	public void testFindAll() throws Exception {
        Tarea tarea = new Tarea();
        tarea.setId(1);
        tarea.setDescripcion("Prueba 1");
        Date date = new Date(System.currentTimeMillis());
        tarea.setFechaCreacion(date);
        tarea.setVigente(true);
        
        List<Tarea> tareas = new ArrayList<Tarea>();
        tareas.add(tarea);
 
        Mockito.when(tareaService.findAll()).thenReturn(tareas);
 
        mockMvc.perform(get("/tareas/getall"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));
    }
	
	@Test
	public void testFindById() throws Exception {
        Tarea tarea = new Tarea();
        tarea.setId(1);
        tarea.setDescripcion("Prueba 2");
        Date date = new Date(System.currentTimeMillis());
        tarea.setFechaCreacion(date);
        tarea.setVigente(true);
 
        Mockito.when(tareaService.findById(1)).thenReturn(tarea);
 
        mockMvc.perform(get("/tareas/get/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("descripcion").value("Prueba 2"));
    }
	
}
